![Alt text](./assets/screeshort.png)

### This is a AI chatbot using Gemini API

We create it for learn about how fetch and response data from API

#### GOOGLE_API_KEY

```bash
AIzaSyCBw8CFbUNreTcCNGq4eTJRDrnymJIXhTU
```

#### API_REQUEST_URL

```bash
https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${GOOGLE_API_KEY}
```

How to donwload ?

- Go to [tochratana](https://tochratana.netlify.app)
- And choose JavaScript Documentation
- On the left side click Exercise Practice
- Select 4 (Gemini chatbot)
- Link download :
  ```bash
  https://tochratana.netlify.app/
  ```
