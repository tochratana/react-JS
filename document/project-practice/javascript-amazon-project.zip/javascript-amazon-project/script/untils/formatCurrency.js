export function FormatCurrency(money) {
  return (money / 100).toFixed(2);
}
